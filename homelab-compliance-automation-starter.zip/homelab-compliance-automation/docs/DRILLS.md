# DRILLS

Quarterly:
- Restore a representative app + dataset
- Re-run compliance scans post-restore
- Publish signed report (PDF + JSON) to `reports/`
